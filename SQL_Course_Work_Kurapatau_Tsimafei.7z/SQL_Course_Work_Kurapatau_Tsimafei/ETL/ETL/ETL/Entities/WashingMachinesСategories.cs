﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETL.Entities
{
    public class WashingMachinesСategories
    {
        public int Washing_Machine_Id { get; set; }

        public int Category_Id { get; set; }

        public DateTime Created_At { get; set; }
    }
}
